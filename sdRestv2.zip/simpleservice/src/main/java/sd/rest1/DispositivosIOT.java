package sd.rest1;

//import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DispositivosIOT {

    private static final Logger LOGGER = Logger.getLogger(DispositivosIOT.class.getName());
    public static final String BASE_URI = "http://localhost:8080/";

  
    public void initializeDevices() {
        LOGGER.log(Level.INFO, "Initializing IoT devices...");
    }

    public void startServer() {
        LOGGER.log(Level.INFO, "Starting IoT server at: {0}", BASE_URI);
    }

    public static void main(String[] args) {
        DispositivosIOT dispositivosIOT = new DispositivosIOT();
        dispositivosIOT.initializeDevices();
        dispositivosIOT.startServer();
    }
}

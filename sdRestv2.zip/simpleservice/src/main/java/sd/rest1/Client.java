package sd.rest1;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Client class to interact with the REST API.
 */
public class Client {

    private static final String BASE_URL = "http://localhost:8080/";
    private final BufferedReader inputReader;
    private String token; 

    public Client() {
        this.inputReader = new BufferedReader(new InputStreamReader(System.in));
    }

    public static void main(String[] args) {
        Client client = new Client();
        client.run();
    }

    public void run() {
        int option = -1;
        while (option != 0) {
            displayMenu();
            try {
                option = Integer.parseInt(inputReader.readLine().trim());
                handleOption(option);
            } catch (IOException | NumberFormatException e) {
                System.out.println("Invalid input. Please try again.");
            }
        }
    }

    private void displayMenu() {
        System.out.println(" ------------------------------ ");
        System.out.println("|                              |");
        System.out.println("| 0 - Exit                     |");
        System.out.println("| 1 - Login                    |");
        System.out.println("| 2 - List Devices             |");
        System.out.println("| 3 - Create Device            |");
        System.out.println("| 4 - Update Device            |");
        System.out.println("| 5 - Delete Device            |");
        System.out.println("| 6 - Check Metrics            |");
        System.out.println(" ------------------------------ ");
        System.out.print("Choose an option: ");
    }

    private void handleOption(int option) throws IOException {
        switch (option) {
            case 1:
                login();
                break;
            case 2:
                if (validateToken()) listDevices();
                break;
            case 3:
                if (validateToken()) createDevice();
                break;
            case 4:
                if (validateToken()) updateDevice();
                break;
            case 5:
                if (validateToken()) deleteDevice();
                break;
                case 6:
                if(validateToken()){
                    menuMetrics();
                }
                break;
            case 0:
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Invalid option. Please choose again.");
                break;
        }
    }

    private void login() throws IOException {
        System.out.print("Enter username: ");
        String username = inputReader.readLine().trim();
        System.out.print("Enter password: ");
        String password = inputReader.readLine().trim();
        String body = "username=" + username + "&password=" + password;
        String response = sendHttpRequest(URI.create(BASE_URL + "auth/login"), "POST", body, null, "application/x-www-form-urlencoded");
    
        if (response.startsWith("Error") || response.contains("Invalid username or password")) {
            System.out.println("Login failed: " + response);
        } else {
            token = response.substring(response.indexOf(":") + 3, response.length() - 2); 
            System.out.println("Login successful. Token: " + token);
        }
    }
    
    

    private boolean validateToken() {
        if (token == null) {
            System.out.println("You are not logged in. Please login first.");
            return false;
        }

        String response = sendGetRequestWithAuth(BASE_URL + "auth/validate", token);
        if (response.contains("Token is valid")) {
            return true;
        } else {
            System.out.println("Token validation failed: " + response);
            return false;
        }
    }

    private void listDevices() {
        String response = sendGetRequestWithAuth(BASE_URL + "devices", token);
        if (response.isEmpty()) {
            System.out.println("No response or failed to connect to the server.");
            return;
        }
    
        try {
            JSONArray devices = new JSONArray(response); 
            if (devices.length() == 0) {
                System.out.println("No devices found.");
                return;
            }
    
            System.out.println(" ---------------------------------------------------------------------- ");
            System.out.printf("| %-5s | %-12s | %-12s | %-10s | %-8s | %-8s | %-5s |\n", 
                              "ID", "Service", "Temperature", "Humidity", "Building", "Floor", "Room");
            System.out.println(" ---------------------------------------------------------------------- ");
            for (int i = 0; i < devices.length(); i++) {
                JSONObject device = devices.getJSONObject(i);
                int id = device.getInt("id");
                String service = device.getString("service");
                double temperature = device.getDouble("temperature");
                double humidity = device.getDouble("humidity");
                String building = device.getString("building");
                String floor = device.getString("floor");
                String room = device.getString("room");
    
                System.out.printf("| %-5d | %-12s | %-12.2f | %-10.2f | %-8s | %-8s | %-5s |\n", 
                                  id, service, temperature, humidity, building, floor, room);
            }
            System.out.println(" ---------------------------------------------------------------------- ");
        } catch (Exception e) {
            System.out.println("Error parsing device data: " + e.getMessage());
        }
    }
    

    private void createDevice() throws IOException {
        System.out.print("Enter room: ");
        String room = inputReader.readLine().trim();
        System.out.print("Enter floor: ");
        String floor = inputReader.readLine().trim();
        System.out.print("Enter building: ");
        String building = inputReader.readLine().trim();
        System.out.print("Enter service: ");
        String service = inputReader.readLine().trim();
        String body = "room=" + room + "&floor=" + floor + "&building=" + building + "&service=" + service;
    
        String response = sendHttpRequest(
            URI.create(BASE_URL + "create/device"), 
            "POST", 
            body, 
            token, 
            "application/x-www-form-urlencoded"
        );
    
        if (response.contains("message")) {
            System.out.println("Response: " + response);
        } else {
            System.out.println("Failed to create device. Response: " + response);
        }
    }
    
    

    private void updateDevice() throws IOException {
        listDevices(); 
        System.out.print("Enter device ID: ");
        String id = inputReader.readLine().trim();
        System.out.print("Enter new room (or leave blank): ");
        String room = inputReader.readLine().trim();
        System.out.print("Enter new floor (or leave blank): ");
        String floor = inputReader.readLine().trim();
        System.out.print("Enter new building (or leave blank): ");
        String building = inputReader.readLine().trim();
        System.out.print("Enter new service (or leave blank): ");
        String service = inputReader.readLine().trim();
    
        Map<String, String> params = new HashMap<>();
        params.put("id", id);
        if (!room.isEmpty()) params.put("room", room);
        if (!floor.isEmpty()) params.put("floor", floor);
        if (!building.isEmpty()) params.put("building", building);
        if (!service.isEmpty()) params.put("service", service);
    
        String response = sendPutRequestWithAuth(BASE_URL + "update/device", params, token);
        parseAndDisplayResponse(response);
    }
    private void deleteDevice() throws IOException {
        listDevices();
        System.out.print("Enter device ID to delete: ");
        String id = inputReader.readLine().trim();
        String url = BASE_URL + "delete/device?id=" + id;
        String response = sendDeleteRequestWithAuth(URI.create(url), token);
        parseAndDisplayResponse(response);
    }

    private String sendGetRequestWithAuth(String url, String token) {
        return sendHttpRequest(URI.create(url), "GET", null, token, "application/json");
    }
    

   /*  private String sendPostRequestWithAuth(String url, Map<String, String> params, String token) {
        String body = buildQueryString(params).substring(1); 
        return sendHttpRequest(URI.create(url), "POST", body, token, "application/x-www-form-urlencoded");
    }*/
    

    private String sendDeleteRequestWithAuth(URI targetURI, String token) {
        return sendHttpRequest(targetURI, "DELETE", null, token, "application/json");
    }
    

    private String sendHttpRequest(URI targetURI, String method, String body, String token, String contentType) {
        StringBuilder response = new StringBuilder();
        HttpURLConnection connection = null;
    
        try {
            URL url = targetURI.toURL();
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(method.toUpperCase());
            connection.setRequestProperty("Accept", "application/json");
    
            
            if (contentType != null) {
                connection.setRequestProperty("Content-Type", contentType);
            }
    
            
            if (token != null && !token.isEmpty()) {
                connection.setRequestProperty("Authorization", "Bearer " + token);
            }
    
            
            if (body != null && (method.equalsIgnoreCase("POST") || method.equalsIgnoreCase("PUT"))) {
                connection.setDoOutput(true);
                try (OutputStream os = connection.getOutputStream()) {
                    os.write(body.getBytes("UTF-8"));
                    os.flush();
                }
            }
    
            
            int status = connection.getResponseCode();
            InputStream inputStream = (status >= 200 && status < 300) ?
                                      connection.getInputStream() : connection.getErrorStream();
    
            
            if (inputStream != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                }
            }
    
            
            if (status >= 200 && status < 300) {
                System.out.println("HTTP Success (" + status + "): " + response);
            } else {
                System.out.println("HTTP Error (" + status + "): " + response);
            }
    
        } catch (IOException e) {
            System.out.println("Failed to connect to the server: " + e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return response.toString();
    }
    
    
    
    

    private String buildQueryString(Map<String, String> params) {
        if (params == null || params.isEmpty()) return "";
        StringBuilder queryString = new StringBuilder("?");
        params.forEach((key, value) -> {
            if (value != null && !value.trim().isEmpty()) {
                queryString.append(key).append("=").append(value).append("&");
            }
        });
        if (queryString.length() > 1) {
            queryString.setLength(queryString.length() - 1); 
        }
        return queryString.toString();
    }
    
    /*private String sendPostRequest(String targetURL, String body) {
        return sendHttpRequest(URI.create(targetURL), "POST", body, null, "application/json");
    }*/
    private String sendPutRequestWithAuth(String url, Map<String, String> params, String token) {
        String body = buildQueryString(params).substring(1);
        return sendHttpRequest(URI.create(url), "PUT", body, token, "application/x-www-form-urlencoded");
    }
    private void parseAndDisplayResponse(String response) {
        try {
            JSONObject jsonResponse = new JSONObject(response);
            if (jsonResponse.has("message")) {
                System.out.println("Success: " + jsonResponse.getString("message"));
            } else if (jsonResponse.has("error")) {
                System.out.println("Error: " + jsonResponse.getString("error"));
            }
        } catch (Exception e) {
            System.out.println("Failed to parse server response: " + e.getMessage());
        }
    }
    private void menuMetrics() throws IOException {
        int option = -1;
        while (option != 0) {
            System.out.println(" ############################### ");
            System.out.println("#        METRICS MENU          #");
            System.out.println("# 1 - Query Room               #");
            System.out.println("# 2 - Query Building           #");
            System.out.println("# 3 - Query Service            #");
            System.out.println("# 4 - Query Floor              #");
            System.out.println("# 0 - Previous Menu            #");
            System.out.println(" ############################### ");
            System.out.print("Choose an option: ");
            try {
                option = Integer.parseInt(inputReader.readLine().trim());
                switch (option) {
                    case 1:
                        queryRoom();
                        break;
                    case 2:
                        queryBuilding();
                        break;
                    case 3:
                        queryService();
                        break;
                    case 4:
                        queryFloor();
                        break;
                    case 0:
                        System.out.println("Returning to main menu...");
                        break;
                    default:
                        System.out.println("Invalid option. Please choose again.");
                        break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
    private void queryRoom() throws IOException {
        System.out.print("Enter room (required): ");
        String room = inputReader.readLine().trim();
        System.out.print("Enter floor (optional): ");
        String floor = inputReader.readLine().trim();
        System.out.print("Enter building (optional): ");
        String building = inputReader.readLine().trim();
        System.out.print("Enter start date (YYYY-MM-DD, optional): ");
        String startDate = inputReader.readLine().trim();
        System.out.print("Enter end date (YYYY-MM-DD, optional): ");
        String endDate = inputReader.readLine().trim();
    
        Map<String, String> params = new HashMap<>();
        params.put("room", room);
        if (!floor.isEmpty()) params.put("floor", floor);
        if (!building.isEmpty()) params.put("building", building);
        if (!startDate.isEmpty()) params.put("startDate", startDate);
        if (!endDate.isEmpty()) params.put("endDate", endDate);
    
        String queryParams = buildQueryString(params);
        String response = sendGetRequestWithAuth(BASE_URL + "metrics/room" + queryParams, token);
        parseAndDisplayMetrics(response);
    }
    
    private void queryBuilding() throws IOException {
        System.out.print("Enter Building (required): ");
        String building = inputReader.readLine().trim();
        System.out.print("Enter start date (YYYY-MM-DD, optional): ");
        String startDate = inputReader.readLine().trim();
        System.out.print("Enter end date (YYYY-MM-DD, optional): ");
        String endDate = inputReader.readLine().trim();
    
        Map<String, String> params = new HashMap<>();
        params.put("building", building);
       // if (!building.isEmpty()) params.put("building", building);
        if (!startDate.isEmpty()) params.put("startDate", startDate);
        if (!endDate.isEmpty()) params.put("endDate", endDate);
    
        String queryParams = buildQueryString(params);
        String response = sendGetRequestWithAuth(BASE_URL + "metrics/building" + queryParams, token);
        parseAndDisplayMetrics(response);
    }
    private void queryService() throws IOException {
        System.out.print("Enter service (required): ");
        String service = inputReader.readLine().trim();
        System.out.print("Enter start date (YYYY-MM-DD, optional): ");
        String startDate = inputReader.readLine().trim();
        System.out.print("Enter end date (YYYY-MM-DD, optional): ");
        String endDate = inputReader.readLine().trim();
    
        Map<String, String> params = new HashMap<>();
        params.put("service", service);
       // if (!building.isEmpty()) params.put("building", building);
        if (!startDate.isEmpty()) params.put("startDate", startDate);
        if (!endDate.isEmpty()) params.put("endDate", endDate);
    
        String queryParams = buildQueryString(params);
        String response = sendGetRequestWithAuth(BASE_URL + "metrics/service" + queryParams, token);
        parseAndDisplayMetrics(response);
    }
    private void queryFloor() throws IOException {
        System.out.print("Enter floor (required): ");
        String floor = inputReader.readLine().trim();
        System.out.print("Enter building (optional): ");
        String building = inputReader.readLine().trim();
        System.out.print("Enter start date (YYYY-MM-DD, optional): ");
        String startDate = inputReader.readLine().trim();
        System.out.print("Enter end date (YYYY-MM-DD, optional): ");
        String endDate = inputReader.readLine().trim();
    
        Map<String, String> params = new HashMap<>();
        params.put("floor", floor);
        if (!building.isEmpty()) params.put("building", building);
        if (!startDate.isEmpty()) params.put("startDate", startDate);
        if (!endDate.isEmpty()) params.put("endDate", endDate);
    
        String queryParams = buildQueryString(params);
        String response = sendGetRequestWithAuth(BASE_URL + "metrics/floor" + queryParams, token);
        parseAndDisplayMetrics(response);
    }
    
    private void parseAndDisplayMetrics(String response) {
        try {
            JSONObject jsonResponse = new JSONObject(response);
    
            if (jsonResponse.has("averageTemperature") && jsonResponse.has("averageHumidity")) {
                System.out.println("Metric Results:");
                System.out.println("Level: " + jsonResponse.getString("level"));
    
                
                if (jsonResponse.optString("value", null) != null) {
                    System.out.println("Value: " + jsonResponse.getString("value"));
                } else {
                    System.out.println("Value: Not specified");
                }
    
                System.out.println("Average Temperature: " + jsonResponse.getDouble("averageTemperature") + "°C");
                System.out.println("Average Humidity: " + jsonResponse.getDouble("averageHumidity") + "%");
            } else if (jsonResponse.has("error")) {
                System.out.println("Error: " + jsonResponse.getString("error"));
            }
        } catch (Exception e) {
            System.out.println("Failed to parse metrics data: " + e.getMessage());
        }
    }
    
    
}

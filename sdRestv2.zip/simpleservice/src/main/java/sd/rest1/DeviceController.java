package sd.rest1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class DeviceController {

    private final String host;
    private final String dbName;
    private final String user;
    private final String password;

    public DeviceController(String host, String dbName, String user, String password) {
        this.host = host;
        this.dbName = dbName;
        this.user = user;
        this.password = password;
    }

    
    public void startUpdatingMetrics() {
        String updateQuery = "UPDATE device SET temperatura = ?, humidade = ?, timestamp = ?";

        try (PostgresConnector connector = new PostgresConnector(host, dbName, user, password);
             Connection connection = connector.getConnection();
             PreparedStatement stmt = connection.prepareStatement(updateQuery)) {

            updateMetricsLoop(stmt);

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

 
    private void updateMetricsLoop(PreparedStatement stmt) {
        try {
            while (true) {
                stmt.setDouble(1, generateRandomTemperature());
                stmt.setDouble(2, generateRandomHumidity());
                stmt.setString(3, getCurrentTimestamp());
                stmt.executeUpdate();

                System.out.println("Updated device metrics at: " + getCurrentTimestamp());
                Thread.sleep(2000);
            }
        } catch (InterruptedException e) {
            System.err.println("Thread interrupted: " + e.getMessage());
            Thread.currentThread().interrupt();
        } catch (SQLException e) {
            System.err.println("SQL execution error: " + e.getMessage());
        }
    }


    private double generateRandomTemperature() {
        return 20 + Math.random() * 11;
    }

    private double generateRandomHumidity() {
        return 0.4 + Math.random() * 0.2;
    }

    private String getCurrentTimestamp() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return LocalDateTime.now().format(formatter);
    }

  
    public static void main(String[] args) {
        DeviceController controller = new DeviceController("localhost", "HospitalEvora", "postgres", "123");
        controller.startUpdatingMetrics();
    }
}

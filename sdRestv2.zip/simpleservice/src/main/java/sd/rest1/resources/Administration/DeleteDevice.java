package sd.rest1.resources.Administration;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import sd.rest1.PostgresConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


@Path("delete/device")
public class DeleteDevice {

    private static final Logger LOGGER = Logger.getLogger(DeleteDevice.class.getName());

    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    public Response eliminacao(@QueryParam("id") int id) {
        if (id <= 0) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("{\"error\": \"Invalid device ID.\"}")
                    .build();
        }

        try (PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "123");
             Connection conn = pc.getConnection()) {

            conn.setAutoCommit(false); 

            
            String deleteLocationQuery = "DELETE FROM location WHERE id = ?;";
            try (PreparedStatement stmt = conn.prepareStatement(deleteLocationQuery)) {
                stmt.setInt(1, id);
                stmt.executeUpdate();
            }

           
            String deleteDeviceQuery = "DELETE FROM device WHERE id = ?;";
            try (PreparedStatement stmt = conn.prepareStatement(deleteDeviceQuery)) {
                stmt.setInt(1, id);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    conn.commit(); 
                    return Response.ok("{\"message\": \"Device deleted successfully.\", \"id\": " + id + "}").build();
                } else {
                    conn.rollback(); 
                    return Response.status(Response.Status.NOT_FOUND)
                            .entity("{\"error\": \"Device with ID " + id + " not found.\"}")
                            .build();
                }
            }

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database error: {0}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("{\"error\": \"Failed to delete device.\", \"details\": \"" + e.getMessage() + "\"}")
                    .build();
        }
    }
}

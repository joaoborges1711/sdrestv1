package sd.rest1;
import org.eclipse.paho.client.mqttv3.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Locale;

public class IoTDeviceSimulator {

    private static final String BROKER_URL = "tcp://localhost:1883";
    private static final String TOPIC = "hospital/metrics";
    private static final String CLIENT_ID = "IoTDeviceSimulator";

    public static void main(String[] args) {
        try {
            MqttClient client = new MqttClient(BROKER_URL, CLIENT_ID);
            client.connect();

            Random random = new Random();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            Locale.setDefault(Locale.US);
            try (PostgresConnector connector = new PostgresConnector("localhost", "HospitalEvora", "postgres", "123");
                 Connection connection = connector.getConnection();
                 Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {
                String query = "SELECT id FROM device";
                ResultSet rs = stmt.executeQuery(query);
                while (true) {
                    rs.beforeFirst(); 
                    while (rs.next()) {
                        int deviceId = rs.getInt("id");
                        double temperature = 20 + random.nextDouble() * 10; 
                        double humidity = 0.4 + random.nextDouble() * 0.2; 
                        String timestamp = LocalDateTime.now().format(formatter);

                        String payload = String.format(Locale.US,
                                "{\"id\":%d,\"temperature\":%.2f,\"humidity\":%.2f,\"timestamp\":\"%s\"}",
                                deviceId, temperature, humidity, timestamp);
                        client.publish(TOPIC, new MqttMessage(payload.getBytes()));
                        System.out.println("Message sent: " + payload);
                    }
                    Thread.sleep(5000);
                }

            } catch (SQLException e) {
                System.err.println("Error accessing database: " + e.getMessage());
            }

        } catch (MqttException | InterruptedException e) {
            System.err.println("Error in IoT simulator: " + e.getMessage());
        }
    }
}

package sd.rest1;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class Device {

    private final int id;
    private double temperature;
    private double humidity;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;

    public Device(int id) {
        this.id = id;
        updateMetrics();
    }

    @JsonProperty("device_id")
    public int getDeviceId() {
        return id;
    }

    public void updateMetrics() {
        Random random = new Random();
        this.temperature = 20 + random.nextDouble() * 11; 
        this.humidity = 0.4 + random.nextDouble() * 0.2;  
        this.timestamp = LocalDateTime.now();
    }

    
    @JsonProperty("device_metrics")
    public String getMetrics() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return String.format("Device ID: %d, Temperature: %.2f, Humidity: %.2f, Timestamp: %s",
                id, temperature, humidity, timestamp.format(formatter));
    }

   
    public static void main(String[] args) throws Exception {
        Device device = new Device(1);
        System.out.println("Initial Metrics:");
        System.out.println(device.getMetrics());

        
        com.fasterxml.jackson.databind.ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(device);
        System.out.println("\nSerialized JSON:");
        System.out.println(jsonString);
    }
}

package sd.rest1;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;


public class ParameterStringBuilder {

    public static String buildQueryString(Map<String, String> params) throws UnsupportedEncodingException {
        if (params == null || params.isEmpty()) {
            return "";
        }

        StringBuilder queryString = new StringBuilder();

        for (Map.Entry<String, String> entry : params.entrySet()) {
            queryString.append(encode(entry.getKey()))
                       .append("=")
                       .append(encode(entry.getValue()))
                       .append("&");
        }

        return queryString.substring(0, queryString.length() - 1);
    }
    private static String encode(String value) throws UnsupportedEncodingException {
        return URLEncoder.encode(value, "UTF-8");
    }
}

package sd.rest1.resources.Administration;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import sd.rest1.PostgresConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Root resource for environmental data checks.
 */
@Path("metrics")
public class Metrics {

    private static final Logger LOGGER = Logger.getLogger(Metrics.class.getName());

    /**
     * Queries room metrics based on provided parameters.
     */
    @GET
@Path("/room")
@Produces(MediaType.APPLICATION_JSON)
public Response checkRoom(@QueryParam("room") String room,
                          @QueryParam("floor") String floor,
                          @QueryParam("building") String building,
                          @QueryParam("startDate") String startDate,
                          @QueryParam("endDate") String endDate) {
    try {
        String query = buildQuery("room", room, floor, building, startDate, endDate, null);
        return executeQuery(query, "room", room, floor, building, startDate, endDate, null);
    } catch (IllegalArgumentException e) {
        return Response.status(Response.Status.BAD_REQUEST).entity(Map.of("error", e.getMessage())).build();
    }
}


    /**
     * Queries floor metrics based on provided parameters.
     */
    @GET
    @Path("/floor")
    @Produces(MediaType.APPLICATION_JSON)
    public Response checkFloor(@QueryParam("floor") String floor,
                               @QueryParam("building") String building,
                               @QueryParam("startDate") String startDate,
                               @QueryParam("endDate") String endDate) {
        try {
            String query = buildQuery("floor", null, floor, building, startDate, endDate, null);
            return executeQuery(query, "floor", null, floor, building, startDate, endDate, null);
        } catch (IllegalArgumentException e) {
            return Response.status(Response.Status.BAD_REQUEST).entity(Map.of("error", e.getMessage())).build();
        }
    }
    

    /**
     * Queries building metrics based on provided parameters.
     */
    @GET
@Path("/building")
@Produces(MediaType.APPLICATION_JSON)
public Response checkBuilding(@QueryParam("building") String building,
                              @QueryParam("startDate") String startDate,
                              @QueryParam("endDate") String endDate) {
    try {
        String query = buildQuery("building", null, null, building, startDate, endDate, null);
        return executeQuery(query, "building", null, null, building, startDate, endDate, null);
    } catch (IllegalArgumentException e) {
        return Response.status(Response.Status.BAD_REQUEST).entity(Map.of("error", e.getMessage())).build();
    }
}


    /**
     * Queries service metrics based on provided parameters.
     */
    @GET
@Path("/service")
@Produces(MediaType.APPLICATION_JSON)
public Response checkService(@QueryParam("service") String service,
                              @QueryParam("startDate") String startDate,
                              @QueryParam("endDate") String endDate) {
    try {
        String query = buildQuery("service", null, null, null, startDate, endDate, service);
        return executeQuery(query, "service", null, null, null, startDate, endDate, service);
    } catch (IllegalArgumentException e) {
        return Response.status(Response.Status.BAD_REQUEST).entity(Map.of("error", e.getMessage())).build();
    }
}


    /**
     * Builds a SQL query based on the parameters provided.
     */
    private String buildQuery(String level, String room, String floor, String building,
                          String startDate, String endDate, String service) {
    StringBuilder query = new StringBuilder("SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, " +
            "AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE device.id = location.id");

    if (room != null && !room.isEmpty()) query.append(" AND location.room = ?");
    if (floor != null && !floor.isEmpty()) query.append(" AND location.floor = ?");
    if (building != null && !building.isEmpty()) query.append(" AND location.building = ?");
    if (service != null && !service.isEmpty()) query.append(" AND location.service = ?");

    if (startDate == null && endDate == null) {
        query.append(" AND device.timestamp > now() - INTERVAL '7 DAYS'"); // Exemplo: 7 dias
    } else {
        if (startDate != null && !startDate.isEmpty()) query.append(" AND device.timestamp >= ?");
        if (endDate != null && !endDate.isEmpty()) query.append(" AND device.timestamp <= ?");
    }

    return query.append(";").toString();
}






    /**
     * Executes the SQL query and returns the response.
     */
    private Response executeQuery(String query, String level, String room, String floor,
                        String building, String startDate, String endDate, String service) {
                    try (PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "123");
                    Connection conn = pc.getConnection();
                    PreparedStatement stmt = conn.prepareStatement(query)) {

                    // Liga os valores aos placeholders na query
                    int index = 1;
                    if (room != null && !room.isEmpty()) stmt.setString(index++, room);
                    if (floor != null && !floor.isEmpty()) stmt.setString(index++, floor);
                    if (building != null && !building.isEmpty()) stmt.setString(index++, building);
                    if (service != null && !service.isEmpty()) stmt.setString(index++, service);
                    if (startDate != null && !startDate.isEmpty()) stmt.setString(index++, startDate);
                    if (endDate != null && !endDate.isEmpty()) stmt.setString(index++, endDate);

                    LOGGER.info("Generated SQL: " + query);
                    LOGGER.info("Parameters:");
                    if (room != null) LOGGER.info("Room: " + room);
                    if (floor != null) LOGGER.info("Floor: " + floor);
                    if (building != null) LOGGER.info("Building: " + building);
                    if (service != null) LOGGER.info("Service: " + service);
                    if (startDate != null) LOGGER.info("Start Date: " + startDate);
                    if (endDate != null) LOGGER.info("End Date: " + endDate);

                    LOGGER.info("Executing query: " + query);

                    // Executa a query e processa os resultados
                    try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                    double tempAVG = rs.getDouble("tempAVG");
                    double humiAVG = rs.getDouble("humiAVG");

                    // Verifica se os valores retornados são nulos
                    if (rs.wasNull()) {
                    tempAVG = 0.0;
                    humiAVG = 0.0;
                    }

                    // Define o valor com base nos parâmetros fornecidos
                    String value = null;
                    if (service != null && !service.isEmpty()) {
                    value = service;
                    } else if (room != null && !room.isEmpty()) {
                    value = room;
                    } else if (floor != null && !floor.isEmpty()) {
                    value = floor;
                    } else if (building != null && !building.isEmpty()) {
                    value = building;
                    }

                    // Prepara o resultado
                    Map<String, Object> result = new HashMap<>();
                    result.put("level", level);
                    result.put("value", value != null ? value : "Not specified");
                    result.put("averageTemperature", tempAVG);
                    result.put("averageHumidity", humiAVG);

                    return Response.ok(result).build();
                    } else {
                    return Response.status(Response.Status.NOT_FOUND)
                    .entity(Map.of("error", "No metrics found for " + level))
                    .build();
                    }
                    }
                    } catch (SQLException e) {
                    LOGGER.log(Level.SEVERE, "Database error: {0}", e.getMessage());
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(Map.of("error", "Database error", "details", e.getMessage()))
                    .build();
                    }
}


    
    
    
    
    
}

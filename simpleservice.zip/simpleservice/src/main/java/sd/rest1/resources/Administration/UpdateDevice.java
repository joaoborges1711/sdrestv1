package sd.rest1.resources.Administration;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import sd.rest1.PostgresConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Root resource for updating device location information.
 */
@Path("update/device")
public class UpdateDevice {

    private static final Logger LOGGER = Logger.getLogger(UpdateDevice.class.getName());

    /**
     * Updates the location of an existing IoT device.
     *
     * @param id Device ID to update.
     * @param room New room (optional).
     * @param floor New floor (optional).
     * @param service New service (optional).
     * @param building New building (optional).
     * @return JSON response indicating the success or failure of the operation.
     */
    @PUT
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateDevice(@FormParam("id") int id,
                                 @FormParam("room") String room,
                                 @FormParam("floor") String floor,
                                 @FormParam("service") String service,
                                 @FormParam("building") String building) {

        validateParams(id);

        try (PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "123");
             Connection conn = pc.getConnection()) {

            // Retrieve existing location details
            String existingDetailsQuery = "SELECT * FROM location WHERE id = ?;";
            try (PreparedStatement stmt = conn.prepareStatement(existingDetailsQuery)) {
                stmt.setInt(1, id);
                ResultSet res = stmt.executeQuery();

                if (res.next()) {
                    room = (room != null && !room.isEmpty()) ? room : res.getString("room");
                    floor = (floor != null && !floor.isEmpty()) ? floor : res.getString("floor");
                    building = (building != null && !building.isEmpty()) ? building : res.getString("building");
                    service = (service != null && !service.isEmpty()) ? service : res.getString("service");
                } else {
                    return Response.status(Response.Status.NOT_FOUND)
                            .entity(Map.of("error", "Device with ID " + id + " not found."))
                            .build();
                }
            }

            // Update location details
            String updateLocationQuery = "UPDATE location SET room = ?, floor = ?, service = ?, building = ? WHERE id = ?;";
            try (PreparedStatement stmt = conn.prepareStatement(updateLocationQuery)) {
                stmt.setString(1, room);
                stmt.setString(2, floor);
                stmt.setString(3, service);
                stmt.setString(4, building);
                stmt.setInt(5, id);
                int updatedRows = stmt.executeUpdate();

                if (updatedRows > 0) {
                    return Response.ok(Map.of(
                            "message", "Device location updated successfully.",
                            "id", id,
                            "room", room,
                            "floor", floor,
                            "service", service,
                            "building", building
                    )).build();
                } else {
                    return Response.status(Response.Status.NOT_FOUND)
                            .entity(Map.of("error", "Device with ID " + id + " not found."))
                            .build();
                }
            }

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Database error: {0}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(Map.of(
                            "error", "Failed to update device location.",
                            "details", e.getMessage()
                    )).build();
        }
    }

    private void validateParams(int id) {
        if (id <= 0) {
            throw new WebApplicationException(
                    Response.status(Response.Status.BAD_REQUEST)
                            .entity(Map.of("error", "Device ID must be greater than 0."))
                            .build()
            );
        }
    }
}
